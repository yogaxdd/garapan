import requests
import time
import asyncio
from telegram import Bot, InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.constants import ParseMode
from telegram.ext import ApplicationBuilder, CallbackQueryHandler, CommandHandler, ContextTypes
from datetime import datetime

# Konfigurasi bot dan daftar chat ID
auth_bot = "7415442849:AAHiwXShvPRjrIs40kdXvheX9l0ea32U1WQ"
chat_ids = ["-1002173689606"] # Tambahkan ID chat lainnya ke dalam daftar ini


message = (
    "⚠️ Server Telah Dishutdown!\n"
    " \n"
    "Server Kamu Telah Di Shutdown Silahkan Hubungi Admin @yogakokxd Untuk Info Lebih Lanjut"
)

def send_telegram_message(auth_bot, chat_id, message):
    url = f"https://api.telegram.org/bot{auth_bot}/sendMessage"
    payload = {
        'chat_id': chat_id,
        'text': message
    }
    try:
        response = requests.post(url, data=payload)
        if response.status_code == 200:
            print(f"Pesan berhasil dikirim ke chat ID {chat_id}")
            return response.json().get('result', {}).get('message_id')
        else:
            print(f"Error: {response.status_code} saat mengirim ke chat ID {chat_id}")
            return None
    except Exception as e:
        print(f"Error: {e} saat mengirim ke chat ID {chat_id}")
        return None

def delete_telegram_message(auth_bot, chat_id, message_id):
    url = f"https://api.telegram.org/bot{auth_bot}/deleteMessage"
    payload = {
        'chat_id': chat_id,
        'message_id': message_id
    }
    try:
        response = requests.post(url, data=payload)
        if response.status_code == 200:
            print(f"Pesan dengan ID {message_id} berhasil dihapus di chat ID {chat_id}")
        else:
            print(f"Error: {response.status_code} saat menghapus pesan dengan ID {message_id} di chat ID {chat_id}")
    except Exception as e:
        print(f"Error: {e} saat menghapus pesan dengan ID {message_id} di chat ID {chat_id}")

# Menyimpan message_id yang terakhir dikirim untuk setiap chat ID
last_message_ids = {chat_id: None for chat_id in chat_ids}

# Loop untuk mengirim pesan setiap 5 menit
while True:
    for chat_id in chat_ids:
        if last_message_ids[chat_id] is not None:
            delete_telegram_message(auth_bot, chat_id, last_message_ids[chat_id])
        last_message_ids[chat_id] = send_telegram_message(auth_bot, chat_id, message)
    time.sleep(600)
