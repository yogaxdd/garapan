import subprocess
from telegram import Bot
import sys
from datetime import datetime
import asyncio

# Ganti dengan token bot Anda
BOT_TOKEN = '7415442849:AAHiwXShvPRjrIs40kdXvheX9l0ea32U1WQ'
CHAT_ID = '-1002173689606'

async def send_telegram_message(bot_token, chat_id, message):
    bot = Bot(token=bot_token)
    await bot.send_message(chat_id=chat_id, text=message)

def main():
    # Pesan notifikasi
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    message = (
        "✅ BERHASIL MENJALANKAN SCRIPT\n\n"
        "Run : Yescoin Gold Auto Swipe\n"
        "Status : running_without_error\n"
        "Time : {}\n"
        "Version Python : {}\n\n"
        "server by : @yogakokxd"
    ).format(current_time, sys.version.split()[0])

    # Kirim notifikasi ke grup Telegram
    asyncio.run(send_telegram_message(BOT_TOKEN, CHAT_ID, message))
   
    subprocess.run(['python', 'yescoin.py'])

if __name__ == '__main__':
    main()
