﻿
# Tapswap Bot
Auto Tap Tapswap Bot  

Join Here : [TapswapBot](https://t.me/tapswap_bot?start=r_968480911)


## Installation

Install with python

```bash
  1. Download Python 3.10+
  2. Install Module (pip install requests colorama bs4)
  3. Buka Bot TapSwap Di Telegram Web / Desktop
  4. Jika sudah muncul QR "Leave the desktop gaming...."
  5. Klik Kanan Inspect > Application > Session Storage > app.tapswap.club
  6. copy tgwebappdata (full semua tanpa tanda kutip) query_id=xxxx atau user_id=xxx
  7. Paste di init_data  
```


## Features
- Auto KYC Binance
- Auto Claim League
- Auto Content ID
- Auto Use Booster Energy
- Auto Use Booster Tap
- Auto Tap 10000 Times jika boost
- Auto Tap All Energy (1x Tap energy habis)
- Auto Upgrade All
- Multi Account
- Tanpa APP_ID Telegram

## Screenshots

![App Screenshot](https://i.ibb.co.com/BBFqwWH/Cuplikan-layar-2024-05-31-173312.png)

