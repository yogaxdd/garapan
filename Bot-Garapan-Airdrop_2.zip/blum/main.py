import os
import subprocess
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Updater, CommandHandler, CallbackContext, CallbackQueryHandler, Application, ContextTypes

# Ganti dengan token bot Anda
TOKEN = '7491851391:AAGhM13yM-2vkKpRQ9GtC-T1Ge0HgSTuxlc'

async def start(update: Update, context: CallbackContext) -> None:
    keyboard = [
        [InlineKeyboardButton("Cek List", callback_data='ceklist')],
        [InlineKeyboardButton("Buka PowerShell Baru", callback_data='newps')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text('Pilih opsi:', reply_markup=reply_markup)

async def ceklist(update: Update, context: CallbackContext) -> None:
    result = subprocess.run(['powershell', '-Command', 'ls'], capture_output=True, text=True)
    await update.message.reply_text(result.stdout)

async def new_powershell_window(update: Update, context: CallbackContext) -> None:
    subprocess.Popen(['powershell', '-NoExit', '-Command', 'Start-Process', 'powershell'])
    await update.message.reply_text("Jendela PowerShell baru telah dibuka.")

async def button(update: Update, context: CallbackContext) -> None:
    query = update.callback_query
    await query.answer()
    
    if query.data == 'ceklist':
        result = subprocess.run(['powershell', '-Command', 'ls'], capture_output=True, text=True)
        await query.edit_message_text(result.stdout)
    elif query.data == 'newps':
        await new_powershell_window(update, context)
        await query.edit_message_text("Jendela PowerShell baru telah dibuka.")

def main() -> None:
    application = Application.builder().token(TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(button))

    application.run_polling()

if __name__ == '__main__':
    main()
