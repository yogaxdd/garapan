
# DejenDog 
DejenDog BOT

Register Here : [DejenDog](https://t.me/DejenDogBot?start=eba7c5d3)

Free 300.000 $HIT

## Features

- Auto Upgrade
- Auto 1x Tap
- Auto Clear Task
- Auto Get token
- Multi Account

## Installation

Install with python

    1. Download Python 3.10+
    2. Install Module (pip install requests colorama)
    3. Buka Bot DejenDog di PC (Telegram Web / Desktop)
    4. Jika sudah terbuka > Klik kanan Inspect
    5. Di Application > Session Storage > https://djdog.io
    6. __telegram__initParams ambil tgwebappdata "query_idxxxx" atau "user_id=" tanpa kutip 
    7. Paste di data.txt
    8. python dejen.py

 

![SS](https://i.ibb.co.com/HC7mHpw/Cuplikan-layar-2024-07-03-161059.png)