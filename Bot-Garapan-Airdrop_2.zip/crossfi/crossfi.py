bot.crossfi.org
test-bot.crossfi.org
testpad.xfi.foundation