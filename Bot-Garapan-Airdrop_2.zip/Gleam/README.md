# Gleam


![image](https://github.com/AirDropFamilyIDN/AutoFarmGleam/assets/169967728/fb84f8a0-c424-4b7b-891b-7107b09c4158)


part 2 : https://t.me/GleamRewardsBot/app?startapp=cmM9ZDA0Zjg5MWU

# How To Run Bot
```
 git clone https://github.com/AirdropFamilyIDN-V2-0/Gleam.git
```
```
cd Gleam
```
```
edit token data.txt
```
```
pip install -r requirements.txt
```
```
py main.py
```

# License ada di Grup AirDropFamilyIDN
Komunitas : https://t.me/AirdropFamilyIDN
