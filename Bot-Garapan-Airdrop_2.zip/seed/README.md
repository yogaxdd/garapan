
# Seed Mine Bot
Seed Mine Bot . Subscribe my github and also give stars if you like this tool :) 

Register Here : [Seed](https://t.me/seed_coin_bot/app?startapp=968480911)

## Installation

Install with python

1. Download Python 3.10+
2. Install Module (pip install requests colorama)
3. Buka Bot Seed di PC (Telegram Desktop)
4. Jika sudah terbuka > Klik kanan Inspect
5. Di Application > Session Storage
6. __telegram__initParams ambil tgwebappdata "query_idxxxx" tanpa kutip 
7. python seed.py 


## Features
- Auto Upgrade
- Auto Claim 
- Multi Account

## Screenshots

![App Screenshot](https://i.ibb.co.com/g30Z2dP/Cuplikan-layar-2024-06-19-170026.png)
