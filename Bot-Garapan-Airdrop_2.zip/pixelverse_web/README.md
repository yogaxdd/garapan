
# Pixelweb Auto Refferal
Auto Refferal Pixelweb

Register Here : [Pixelverse](https://dashboard.pixelverse.xyz/?ref=uccauuauan&v=uccauuauan45072)

## Install
- Use python
- Install Module aiohttp bs4
## Features

- Auto Get Domain
- Auto Refferal

## Get this tool

![SS](https://i.ibb.co.com/r40Fd1c/Cuplikan-layar-2024-06-23-095631.png)
