
# Pixelverse Dashboard
Bot Pixelverse Dashboard

Register Here : [Pixelverse](https://dashboard.pixelverse.xyz/?ref=uccauuauan&v=uccauuauan45072)


## Install
- Download Python
- Install module colorama requests
- Ambil authorization token [CEK SS](https://imgbb.com/ZK452P1)

## Features

- Auto Daily
- Auto Upgrade Pet
- Auto Cek Cheater
- Auto Cek Profile
- Multi Account

